package frame;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;

import Server.Receiver;
import utils.IsNum;
import utils.TransToExcel;
import java.awt.Component;
import javax.swing.ScrollPaneConstants;

public class frame extends JFrame {

	private ServerSocket serverSocket;
	private Socket socket;
	private Boolean lock = true;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTable table;
	private JTable table_1;
	private TimeSeriesCollection dataset = new TimeSeriesCollection();// 数据集
	private final TimeSeries timeSeries = new TimeSeries("", Millisecond.class);// 创建时间序
	private double toplimit;
	private double lowerlimit;
	private String testParam;
	private String testAddress;
	private int prot;
	private List<Map<String, String>> datas = new ArrayList<>();
	private Date date = new Date(System.currentTimeMillis());
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	private String time = sdf.format(date);
	private JFreeChart result;
	private String writePath = "datas.txt";
	private JTextField textField_6;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_27;
	private JTextField textField_28;
	private JTextField textField_29;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;

	/**
	 * Launch the application.
	 */
	public static String[] convertStrToArray(String str) {
		String[] strArray = null;
		strArray = str.split("/"); // 拆分字符为"," ,然后把结果交给数组strArray
		return strArray;
	}

	/**
	 * 
	 * @param calculator
	 * @param widthRate
	 *            宽度比例
	 * @param heightRate
	 *            高度比例
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame frame = new frame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void setXYPolt(XYPlot plot) {
		plot.setDomainGridlinePaint(Color.LIGHT_GRAY);
		plot.setRangeGridlinePaint(Color.LIGHT_GRAY);
		XYItemRenderer r = plot.getRenderer();
		if (r instanceof XYLineAndShapeRenderer) {
			XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) r;
			renderer.setBaseShapesVisible(true);
			renderer.setBaseShapesFilled(false);
		}
	}

	private JFreeChart createChart(XYDataset dataset) {

		// 增加汉字支持

		/**
		 * 第一个参数是设置折线图的主题 第二个参数是设置折线图的x 第三个参数是设置折线图的y 是否显示图表中每条数据序列的说明 是否显示工具提示
		 * 是否显示图表中设置的url网络连接
		 */
		result = ChartFactory.createTimeSeriesChart("", "", "", dataset, false, true, false);
		result.setBackgroundPaint(Color.white);
		XYPlot plot = result.getXYPlot();
		setXYPolt(plot);
		return result;
	}

	/**
	 * Create the frame.
	 */
	public frame() {
		// 用来设置窗口随屏幕大小改变
		// sizeWindowOnScreen(this, 0.6, 0.6);
		// this.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1955, 1035);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("  端口号");
		lblNewLabel.setFont(new Font("宋体", Font.PLAIN, 22));
		lblNewLabel.setBounds(1773, 243, 128, 81);
		lblNewLabel.setBorder(BorderFactory.createLineBorder(Color.gray));
		contentPane.add(lblNewLabel);

		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("宋体", Font.PLAIN, 22));
		textField.setBounds(1773, 328, 128, 102);
		contentPane.add(textField);
		textField.setColumns(10);
		ImageIcon icon = new ImageIcon("src/image/timg.jpg");
		this.setIconImage(icon.getImage());

		JScrollPane scrollPane = new JScrollPane();

		scrollPane.setBounds(28, 500, 1720, 467);
		contentPane.add(scrollPane);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		ChartPanel chartPanel = new ChartPanel((JFreeChart) null);
		scrollPane.setViewportView(chartPanel);

		final JButton btnNewButton_4 = new JButton("运行");
		btnNewButton_4.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_4.setBounds(1773, 434, 128, 87);
		contentPane.add(btnNewButton_4);

		final long threadid;
		// final Thread current;
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Thread(new Runnable() {

					@Override
					public void run() {
						if (textField.getText().trim().equals("") || textField_1.getText().trim().equals("")
								|| textField_2.getText().trim().equals("")) {
							if (textField.getText().trim().equals("")) {
								textField.setText("请输入端口号");

							}
							if (textField_1.getText().trim().equals("")) {
								textField_1.setText("请输入上限");

							}

							if (textField_2.getText().trim().equals("")) {
								textField_2.setText("请输入下限");

							}
							btnNewButton_4.setEnabled(true);

						} else if (!IsNum.isNumeric(textField.getText().trim())
								|| !IsNum.isNumeric(textField_1.getText().trim())
								|| !IsNum.isNumeric(textField_2.getText().trim())) {
							if (!IsNum.isNumeric(textField.getText().trim())) {
								textField.setText("输入数字");

							}
							if (!IsNum.isNumeric(textField_1.getText().trim())) {
								textField_1.setText("输入数字");

							}

							if (!IsNum.isNumeric(textField_2.getText().trim())) {
								textField_2.setText("输入数字");

							}
							btnNewButton_4.setEnabled(true);
						} else if (Double.parseDouble(textField_1.getText()) < Double
								.parseDouble(textField_2.getText())) {
							textField_1.setText("上限不能小于下限");
							textField_2.setText("上限不能小于下限");
							btnNewButton_4.setEnabled(true);

						} else if (textField_3.getText().trim().equals("") || textField_4.getText().trim().equals("")) {
							textField_3.setText("请输入参数");
							textField_4.setText("请输入地址");
							btnNewButton_4.setEnabled(true);
						} else {
							String s = textField.getText() + "/" + textField_1.getText() + "/" + textField_2.getText()
									+ "/" + textField_3.getText() + "/" + textField_4.getText();

							Writeinfo(s);

							btnNewButton_4.setEnabled(false);

							prot = Integer.parseInt(textField.getText());
							toplimit = Double.parseDouble(textField_1.getText());
							lowerlimit = Double.parseDouble(textField_2.getText());
							testParam = textField_3.getText();
							testAddress = textField_4.getText();

							Receiver receiver;
							try {
								serverSocket = new ServerSocket(prot);
								receiver = new Receiver(prot, toplimit, lowerlimit, testParam, testAddress);
								// textArea.append("打开端口成功，等待数据...\n");
								receiver.receive(dataset, timeSeries, table_1, textField_5, lowerlimit, toplimit,
										serverSocket, datas);
							} catch (IOException e1) {
								e1.printStackTrace();
								// textArea.append("端口被占用\n");
							}
							// }
							catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						}
					}
				}).start();

			}
		});

		JButton btnNewButton_1 = new JButton("断开");
		btnNewButton_1.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					serverSocket.close();
					// lock=false;
					// socket.close();
					if (serverSocket.isClosed()) {
						System.out.println("closed");
					}
					btnNewButton_4.setEnabled(true);

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				// sockets

			}
		});
		btnNewButton_1.setBounds(1773, 696, 128, 89);
		contentPane.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("导出值");
		btnNewButton_2.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				TransToExcel transToExcel = new TransToExcel();
				// Date date = new Date(System.currentTimeMillis());
				// SimpleDateFormat sdf = new
				// SimpleDateFormat("yyyyMMddHHmmss");
				// String time = sdf.format(date);
				// JFileChooser jf = new JFileChooser();
				// 点击文件夹将文件保存
				// jf.setFileSelectionMode(JFileChooser.SAVE_DIALOG
				// | JFileChooser.DIRECTORIES_ONLY);
				// jf.setDialogTitle("选择文件夹");
				// jf.showDialog(null, null);
				// File fi = jf.getSelectedFile();
				String outdir = "C:\\output";
				File dir = new File(outdir);
				if (!dir.exists()) {
					dir.mkdir();
				}
				String file = outdir + "\\" + time + ".xls";
				try {
					OutputStream os = new FileOutputStream(file);
					String[] headers = { "端口号", "报警上限", "报警下限", "测量参数", "测量地址", "记录值", "记录时间" };
					// datas.add(map);
					transToExcel.exporteExcel("学生表", headers, datas, os);
					os.close();
					ChartUtilities.saveChartAsPNG(new File("C:\\output\\" + "n" + ".png"), result, 550, 250);

					// 打开文件夹
					java.awt.Desktop.getDesktop().open(dir);
				} catch (FileNotFoundException e1) {
					System.out.println("无法找到文件");

					e1.printStackTrace();
				} catch (IOException e1) {
					System.out.println("写入文件失败");

				}

			}
		});
		btnNewButton_2.setBounds(2083, 1438, 101, 46);
		contentPane.add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("清空");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
				textField_5.setText("");
			}
		});
		btnNewButton_3.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_3.setBounds(2083, 1481, 101, 46);
		contentPane.add(btnNewButton_3);

		JLabel lblNewLabel_1 = new JLabel("    报警上限");
		lblNewLabel_1.setFont(new Font("宋体", Font.PLAIN, 22));
		lblNewLabel_1.setBounds(291, 65, 148, 46);
		lblNewLabel_1.setBorder(BorderFactory.createLineBorder(Color.gray));

		contentPane.add(lblNewLabel_1);

		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setFont(new Font("宋体", Font.PLAIN, 22));
		textField_1.setBounds(291, 112, 148, 46);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("   报警下限");
		lblNewLabel_2.setFont(new Font("宋体", Font.PLAIN, 22));
		lblNewLabel_2.setBounds(440, 65, 132, 46);
		lblNewLabel_2.setBorder(BorderFactory.createLineBorder(Color.gray));

		contentPane.add(lblNewLabel_2);

		textField_2 = new JTextField();
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setFont(new Font("宋体", Font.PLAIN, 22));
		textField_2.setBounds(440, 112, 132, 46);
		contentPane.add(textField_2);
		textField_2.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("  测量参数");
		lblNewLabel_3.setFont(new Font("宋体", Font.PLAIN, 22));
		lblNewLabel_3.setBounds(161, 65, 132, 46);
		lblNewLabel_3.setBorder(BorderFactory.createLineBorder(Color.gray));

		contentPane.add(lblNewLabel_3);

		textField_3 = new JTextField();
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setFont(new Font("宋体", Font.PLAIN, 22));
		textField_3.setBounds(159, 112, 134, 46);
		contentPane.add(textField_3);
		textField_3.setColumns(10);

		JLabel lblNewLabel_4 = new JLabel("  测量地址");
		lblNewLabel_4.setFont(new Font("宋体", Font.PLAIN, 22));
		lblNewLabel_4.setBounds(1773, 525, 128, 87);
		lblNewLabel_4.setBorder(BorderFactory.createLineBorder(Color.gray));

		contentPane.add(lblNewLabel_4);

		textField_4 = new JTextField();
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setFont(new Font("宋体", Font.PLAIN, 22));
		textField_4.setBounds(1773, 614, 128, 81);
		contentPane.add(textField_4);
		textField_4.setColumns(10);

		JLabel lblNewLabel_5 = new JLabel("常州大学校园温度监测系统");
		lblNewLabel_5.setFont(new Font("宋体", Font.PLAIN, 32));
		lblNewLabel_5.setBounds(697, 18, 432, 32);

		contentPane.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("          当前值");
		lblNewLabel_6.setFont(new Font("宋体", Font.PLAIN, 22));
		lblNewLabel_6.setBounds(29, 159, 264, 62);
		lblNewLabel_6.setBorder(BorderFactory.createLineBorder(Color.gray));

		contentPane.add(lblNewLabel_6);

		textField_5 = new JTextField();
		textField_5.setHorizontalAlignment(SwingConstants.CENTER);
		textField_5.setFont(new Font("宋体", Font.PLAIN, 22));
		textField_5.setBounds(30, 220, 263, 62);
		contentPane.add(textField_5);
		textField_5.setColumns(10);

		JLabel lblNewLabel_7 = new JLabel("          报警记录");
		lblNewLabel_7.setFont(new Font("宋体", Font.PLAIN, 22));
		lblNewLabel_7.setBounds(291, 159, 281, 62);
		lblNewLabel_7.setBorder(BorderFactory.createLineBorder(Color.gray));

		contentPane.add(lblNewLabel_7);

		table_1 = new JTable();
		table_1.setEnabled(false);
		table_1.setFont(new Font("宋体", Font.PLAIN, 22));

		table_1.setShowHorizontalLines(true);
		table_1.setRowHeight(30);

		JScrollPane scrollPane_1 = new JScrollPane(table_1);
		scrollPane_1.setBounds(290, 220, 282, 62);
		scrollPane_1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane_1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

		contentPane.add(scrollPane_1);
		
		JLabel label = new JLabel("   测量通道");
		label.setFont(new Font("宋体", Font.PLAIN, 22));
		label.setBorder(BorderFactory.createLineBorder(Color.gray));
		label.setBounds(32, 65, 128, 46);
		contentPane.add(label);
		
		textField_6 = new JTextField();
		textField_6.setHorizontalAlignment(SwingConstants.CENTER);
		textField_6.setFont(new Font("宋体", Font.PLAIN, 22));
		textField_6.setColumns(10);
		textField_6.setBounds(28, 112, 132, 46);
		contentPane.add(textField_6);
				
				JLabel label_13 = new JLabel("   测量通道");
				label_13.setFont(new Font("宋体", Font.PLAIN, 22));
				label_13.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_13.setBounds(28, 280, 132, 46);
				contentPane.add(label_13);
				
				textField_17 = new JTextField();
				textField_17.setHorizontalAlignment(SwingConstants.CENTER);
				textField_17.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_17.setColumns(10);
				textField_17.setBounds(27, 328, 133, 46);
				contentPane.add(textField_17);
				
				JLabel label_14 = new JLabel("  测量参数");
				label_14.setFont(new Font("宋体", Font.PLAIN, 22));
				label_14.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_14.setBounds(159, 280, 134, 46);
				contentPane.add(label_14);
				
				textField_18 = new JTextField();
				textField_18.setHorizontalAlignment(SwingConstants.CENTER);
				textField_18.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_18.setColumns(10);
				textField_18.setBounds(159, 328, 134, 46);
				contentPane.add(textField_18);
				
				JLabel label_15 = new JLabel("    报警上限");
				label_15.setFont(new Font("宋体", Font.PLAIN, 22));
				label_15.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_15.setBounds(291, 280, 148, 46);
				contentPane.add(label_15);
				
				textField_19 = new JTextField();
				textField_19.setHorizontalAlignment(SwingConstants.CENTER);
				textField_19.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_19.setColumns(10);
				textField_19.setBounds(291, 328, 148, 46);
				contentPane.add(textField_19);
				
				JLabel label_16 = new JLabel("   报警下限");
				label_16.setFont(new Font("宋体", Font.PLAIN, 22));
				label_16.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_16.setBounds(440, 280, 132, 46);
				contentPane.add(label_16);
				
				textField_20 = new JTextField();
				textField_20.setHorizontalAlignment(SwingConstants.CENTER);
				textField_20.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_20.setColumns(10);
				textField_20.setBounds(440, 328, 132, 46);
				contentPane.add(textField_20);
				
				JLabel label_17 = new JLabel("          当前值");
				label_17.setFont(new Font("宋体", Font.PLAIN, 22));
				label_17.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_17.setBounds(28, 371, 265, 62);
				contentPane.add(label_17);
				
				JLabel label_18 = new JLabel("          报警记录");
				label_18.setFont(new Font("宋体", Font.PLAIN, 22));
				label_18.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_18.setBounds(291, 371, 281, 62);
				contentPane.add(label_18);
				
				textField_21 = new JTextField();
				textField_21.setHorizontalAlignment(SwingConstants.CENTER);
				textField_21.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_21.setColumns(10);
				textField_21.setBounds(28, 434, 265, 62);
				contentPane.add(textField_21);
				
				JScrollPane scrollPane_7 = new JScrollPane((Component) null);
				scrollPane_7.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
				scrollPane_7.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				scrollPane_7.setBounds(291, 434, 281, 62);
				contentPane.add(scrollPane_7);
				
				JLabel label_1 = new JLabel("   测量通道");
				label_1.setFont(new Font("宋体", Font.PLAIN, 22));
				label_1.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_1.setBounds(621, 65, 132, 46);
				contentPane.add(label_1);
				
				JLabel label_2 = new JLabel("  测量参数");
				label_2.setFont(new Font("宋体", Font.PLAIN, 22));
				label_2.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_2.setBounds(753, 65, 132, 46);
				contentPane.add(label_2);
				
				JLabel label_3 = new JLabel("    报警上限");
				label_3.setFont(new Font("宋体", Font.PLAIN, 22));
				label_3.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_3.setBounds(883, 65, 148, 46);
				contentPane.add(label_3);
				
				JLabel label_4 = new JLabel("   报警下限");
				label_4.setFont(new Font("宋体", Font.PLAIN, 22));
				label_4.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_4.setBounds(1032, 65, 132, 46);
				contentPane.add(label_4);
				
				textField_7 = new JTextField();
				textField_7.setHorizontalAlignment(SwingConstants.CENTER);
				textField_7.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_7.setColumns(10);
				textField_7.setBounds(621, 112, 132, 46);
				contentPane.add(textField_7);
				
				textField_8 = new JTextField();
				textField_8.setHorizontalAlignment(SwingConstants.CENTER);
				textField_8.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_8.setColumns(10);
				textField_8.setBounds(751, 112, 134, 46);
				contentPane.add(textField_8);
				
				textField_9 = new JTextField();
				textField_9.setHorizontalAlignment(SwingConstants.CENTER);
				textField_9.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_9.setColumns(10);
				textField_9.setBounds(883, 112, 148, 46);
				contentPane.add(textField_9);
				
				textField_10 = new JTextField();
				textField_10.setHorizontalAlignment(SwingConstants.CENTER);
				textField_10.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_10.setColumns(10);
				textField_10.setBounds(1032, 112, 132, 46);
				contentPane.add(textField_10);
				
				JLabel label_5 = new JLabel("          当前值");
				label_5.setFont(new Font("宋体", Font.PLAIN, 22));
				label_5.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_5.setBounds(621, 159, 264, 62);
				contentPane.add(label_5);
				
				JLabel label_6 = new JLabel("          报警记录");
				label_6.setFont(new Font("宋体", Font.PLAIN, 22));
				label_6.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_6.setBounds(883, 159, 281, 62);
				contentPane.add(label_6);
				
				textField_11 = new JTextField();
				textField_11.setHorizontalAlignment(SwingConstants.CENTER);
				textField_11.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_11.setColumns(10);
				textField_11.setBounds(621, 220, 263, 62);
				contentPane.add(textField_11);
				
				JScrollPane scrollPane_2 = new JScrollPane((Component) null);
				scrollPane_2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
				scrollPane_2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				scrollPane_2.setBounds(882, 220, 282, 62);
				contentPane.add(scrollPane_2);
				
				JLabel label_19 = new JLabel("   测量通道");
				label_19.setFont(new Font("宋体", Font.PLAIN, 22));
				label_19.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_19.setBounds(621, 280, 132, 46);
				contentPane.add(label_19);
				
				JLabel label_20 = new JLabel("  测量参数");
				label_20.setFont(new Font("宋体", Font.PLAIN, 22));
				label_20.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_20.setBounds(753, 280, 134, 46);
				contentPane.add(label_20);
				
				JLabel label_21 = new JLabel("    报警上限");
				label_21.setFont(new Font("宋体", Font.PLAIN, 22));
				label_21.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_21.setBounds(883, 280, 148, 46);
				contentPane.add(label_21);
				
				JLabel label_22 = new JLabel("   报警下限");
				label_22.setFont(new Font("宋体", Font.PLAIN, 22));
				label_22.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_22.setBounds(1032, 280, 132, 46);
				contentPane.add(label_22);
				
				textField_22 = new JTextField();
				textField_22.setHorizontalAlignment(SwingConstants.CENTER);
				textField_22.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_22.setColumns(10);
				textField_22.setBounds(620, 328, 133, 46);
				contentPane.add(textField_22);
				
				textField_23 = new JTextField();
				textField_23.setHorizontalAlignment(SwingConstants.CENTER);
				textField_23.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_23.setColumns(10);
				textField_23.setBounds(753, 328, 134, 46);
				contentPane.add(textField_23);
				
				textField_24 = new JTextField();
				textField_24.setHorizontalAlignment(SwingConstants.CENTER);
				textField_24.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_24.setColumns(10);
				textField_24.setBounds(883, 328, 148, 46);
				contentPane.add(textField_24);
				
				textField_25 = new JTextField();
				textField_25.setHorizontalAlignment(SwingConstants.CENTER);
				textField_25.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_25.setColumns(10);
				textField_25.setBounds(1032, 328, 132, 46);
				contentPane.add(textField_25);
				
				JLabel label_23 = new JLabel("          当前值");
				label_23.setFont(new Font("宋体", Font.PLAIN, 22));
				label_23.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_23.setBounds(620, 371, 265, 62);
				contentPane.add(label_23);
				
				JLabel label_24 = new JLabel("          报警记录");
				label_24.setFont(new Font("宋体", Font.PLAIN, 22));
				label_24.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_24.setBounds(883, 371, 281, 62);
				contentPane.add(label_24);
				
				textField_26 = new JTextField();
				textField_26.setHorizontalAlignment(SwingConstants.CENTER);
				textField_26.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_26.setColumns(10);
				textField_26.setBounds(620, 434, 265, 62);
				contentPane.add(textField_26);
				
				JScrollPane scrollPane_3 = new JScrollPane((Component) null);
				scrollPane_3.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
				scrollPane_3.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				scrollPane_3.setBounds(883, 434, 281, 62);
				contentPane.add(scrollPane_3);
				
				JLabel label_7 = new JLabel("   测量通道");
				label_7.setFont(new Font("宋体", Font.PLAIN, 22));
				label_7.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_7.setBounds(1207, 65, 128, 46);
				contentPane.add(label_7);
				
				JLabel label_8 = new JLabel("  测量参数");
				label_8.setFont(new Font("宋体", Font.PLAIN, 22));
				label_8.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_8.setBounds(1335, 65, 132, 46);
				contentPane.add(label_8);
				
				JLabel label_9 = new JLabel("    报警上限");
				label_9.setFont(new Font("宋体", Font.PLAIN, 22));
				label_9.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_9.setBounds(1468, 65, 148, 46);
				contentPane.add(label_9);
				
				JLabel label_10 = new JLabel("   报警下限");
				label_10.setFont(new Font("宋体", Font.PLAIN, 22));
				label_10.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_10.setBounds(1616, 65, 132, 46);
				contentPane.add(label_10);
				
				textField_12 = new JTextField();
				textField_12.setHorizontalAlignment(SwingConstants.CENTER);
				textField_12.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_12.setColumns(10);
				textField_12.setBounds(1207, 112, 128, 46);
				contentPane.add(textField_12);
				
				textField_13 = new JTextField();
				textField_13.setHorizontalAlignment(SwingConstants.CENTER);
				textField_13.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_13.setColumns(10);
				textField_13.setBounds(1333, 112, 134, 46);
				contentPane.add(textField_13);
				
				textField_14 = new JTextField();
				textField_14.setHorizontalAlignment(SwingConstants.CENTER);
				textField_14.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_14.setColumns(10);
				textField_14.setBounds(1468, 112, 148, 46);
				contentPane.add(textField_14);
				
				textField_15 = new JTextField();
				textField_15.setHorizontalAlignment(SwingConstants.CENTER);
				textField_15.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_15.setColumns(10);
				textField_15.setBounds(1616, 112, 132, 46);
				contentPane.add(textField_15);
				
				JLabel label_11 = new JLabel("          当前值");
				label_11.setFont(new Font("宋体", Font.PLAIN, 22));
				label_11.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_11.setBounds(1207, 159, 260, 62);
				contentPane.add(label_11);
				
				JLabel label_12 = new JLabel("          报警记录");
				label_12.setFont(new Font("宋体", Font.PLAIN, 22));
				label_12.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_12.setBounds(1468, 159, 281, 62);
				contentPane.add(label_12);
				
				textField_16 = new JTextField();
				textField_16.setHorizontalAlignment(SwingConstants.CENTER);
				textField_16.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_16.setColumns(10);
				textField_16.setBounds(1207, 220, 263, 62);
				contentPane.add(textField_16);
				
				JScrollPane scrollPane_4 = new JScrollPane((Component) null);
				scrollPane_4.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
				scrollPane_4.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				scrollPane_4.setBounds(1468, 220, 282, 62);
				contentPane.add(scrollPane_4);
				
				JLabel label_25 = new JLabel("   测量通道");
				label_25.setFont(new Font("宋体", Font.PLAIN, 22));
				label_25.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_25.setBounds(1207, 280, 132, 46);
				contentPane.add(label_25);
				
				JLabel label_26 = new JLabel("  测量参数");
				label_26.setFont(new Font("宋体", Font.PLAIN, 22));
				label_26.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_26.setBounds(1335, 280, 134, 46);
				contentPane.add(label_26);
				
				JLabel label_27 = new JLabel("    报警上限");
				label_27.setFont(new Font("宋体", Font.PLAIN, 22));
				label_27.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_27.setBounds(1468, 280, 148, 46);
				contentPane.add(label_27);
				
				JLabel label_28 = new JLabel("   报警下限");
				label_28.setFont(new Font("宋体", Font.PLAIN, 22));
				label_28.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_28.setBounds(1616, 280, 132, 46);
				contentPane.add(label_28);
				
				textField_27 = new JTextField();
				textField_27.setHorizontalAlignment(SwingConstants.CENTER);
				textField_27.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_27.setColumns(10);
				textField_27.setBounds(1207, 328, 133, 46);
				contentPane.add(textField_27);
				
				textField_28 = new JTextField();
				textField_28.setHorizontalAlignment(SwingConstants.CENTER);
				textField_28.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_28.setColumns(10);
				textField_28.setBounds(1335, 328, 134, 46);
				contentPane.add(textField_28);
				
				textField_29 = new JTextField();
				textField_29.setHorizontalAlignment(SwingConstants.CENTER);
				textField_29.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_29.setColumns(10);
				textField_29.setBounds(1468, 328, 148, 46);
				contentPane.add(textField_29);
				
				textField_30 = new JTextField();
				textField_30.setHorizontalAlignment(SwingConstants.CENTER);
				textField_30.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_30.setColumns(10);
				textField_30.setBounds(1616, 328, 132, 46);
				contentPane.add(textField_30);
				
				JLabel label_29 = new JLabel("          当前值");
				label_29.setFont(new Font("宋体", Font.PLAIN, 22));
				label_29.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_29.setBounds(1207, 371, 263, 62);
				contentPane.add(label_29);
				
				JLabel label_30 = new JLabel("          报警记录");
				label_30.setFont(new Font("宋体", Font.PLAIN, 22));
				label_30.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_30.setBounds(1467, 371, 281, 62);
				contentPane.add(label_30);
				
				textField_31 = new JTextField();
				textField_31.setHorizontalAlignment(SwingConstants.CENTER);
				textField_31.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_31.setColumns(10);
				textField_31.setBounds(1207, 434, 260, 62);
				contentPane.add(textField_31);
				
				JScrollPane scrollPane_5 = new JScrollPane((Component) null);
				scrollPane_5.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
				scrollPane_5.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				scrollPane_5.setBounds(1467, 434, 281, 62);
				contentPane.add(scrollPane_5);
				
				JLabel label_31 = new JLabel("  报警上限");
				label_31.setFont(new Font("宋体", Font.PLAIN, 22));
				label_31.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_31.setBounds(1773, 65, 128, 93);
				contentPane.add(label_31);
				
				textField_32 = new JTextField();
				textField_32.setHorizontalAlignment(SwingConstants.CENTER);
				textField_32.setFont(new Font("宋体", Font.PLAIN, 22));
				textField_32.setColumns(10);
				textField_32.setBounds(1773, 162, 128, 81);
				contentPane.add(textField_32);
				
				JLabel label_32 = new JLabel("  测量地址");
				label_32.setFont(new Font("宋体", Font.PLAIN, 22));
				label_32.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_32.setBounds(1773, 782, 128, 102);
				contentPane.add(label_32);
				
				JLabel label_33 = new JLabel("  端口号");
				label_33.setFont(new Font("宋体", Font.PLAIN, 22));
				label_33.setBorder(BorderFactory.createLineBorder(Color.gray));
				label_33.setBounds(1773, 886, 128, 81);
				contentPane.add(label_33);
		File file = new File(writePath);
		if (file.exists()) {
			String s = Readinfo();
			String[] datas1 = null;
			if (s != null) {
				datas1 = convertStrToArray(s);
				textField.setText(datas1[0].trim());
				textField_1.setText(datas1[1].trim());
				textField_2.setText(datas1[2].trim());
				textField_3.setText(datas1[3].trim());
				textField_4.setText(datas1[4].trim());
			}
		}
	}

	private void Writeinfo(String s) {
		File file = new File(writePath);
		PrintStream ps;
		try {
			ps = new PrintStream(new FileOutputStream(file));
			ps.println(s);// 往文件里写入字符串

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String Readinfo() {
		// String read=null;
		File file = new File(writePath);
		StringBuilder result = new StringBuilder();
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));// 构造一个BufferedReader类来读取文件
			// FileReader br=new FileReader(file);
			String s = null;
			while ((s = br.readLine()) != null) {// 使用readLine方法，一次读一行
				result.append(System.lineSeparator() + s);
				System.out.println(s);
			}

			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result.toString();

	}
}
